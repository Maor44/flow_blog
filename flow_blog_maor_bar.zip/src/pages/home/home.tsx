import React from 'react';

const Home = () => {
    return (
        <div className="h-5/6 flex items-center justify-center">
            <h1 className="font-bold text-3xl">Home</h1>
        </div>
    );
};

export { Home };