import {DeleteIcon} from "./delete-icon";

export {DeleteIcon};